package a3psc;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Controlador {

    static private Produtos lista[] = new Produtos[0]; // array da classe
    static int id = 0;
    static int acc = 0;
    static DefaultTableModel tabelaProdutos;  //Define uma referência table model

    public static Produtos[] getLista() {
        return lista;
    }

    public static void setLista(Produtos[] lista) {
        Controlador.lista = lista;
    }

    public static void gerarTabela(TelaPrincipal a1) {
        tabelaProdutos = (DefaultTableModel) a1.listaAllProducts.getModel(); // instancia uma table model
        Produtos[] lista1 = getLista(); // cria um array de Produtos que recebe tudo que tiver no array principal de produtos
        tabelaProdutos.setRowCount(0); // apaga todas as linhas da tabela
            for (int i = 0; i < Controlador.getLista().length; i++) {
                // for criado para percorrer toda a lista
                // criamos um array que contem todas as informações de cada produto percorrido
                Object[] listaProdutos = {
                    lista1[i].getId(),
                    lista1[i].getNome(),
                    lista1[i].getCategoria(),
                    lista1[i].getEstoque(),
                    lista1[i].getUndMed(),
                    lista1[i].getVlrUnd()
                };
                tabelaProdutos.addRow(listaProdutos); // adicionamos o array criado dentro da tabela
            }
        } // gera a tabela
    
    public static void newProduct(String nome, String categoria, double qtd, double undMed, double valor, TelaPrincipal a1) { // cria um novo produto
        int contador = 0;
        for (int i = 0; i < lista.length; i++) {
            if(nome.equalsIgnoreCase(lista[i].getNome()) && categoria.equalsIgnoreCase(lista[i].getCategoria())) {
                contador++; // se já existir algum produto com o mesmo nome e categoria, o contador será atribuído
            }
        }
        if(contador == 0) { // se o contador for diferente de zero, quer dizer que o produto que está sendo criado já existe
            // mas se for zero, ele cria o novo produto normalmente
            
        if (acc == lista.length) { // sempre que o acc estiver igual ao tamanho do array, quer dizer que o array está cheio e para
            // adicionar um novo produto será necessário redimensioná-lo, que faremos isso utilizando um array temporário
            
            Produtos temp[] = new Produtos[lista.length + 1]; // cria um array temporario que tem o tamanho da lista + 1
            for (int i = 0; i < lista.length; i++) {
                temp[i] = lista[i];
            } // percorre toda a lista e adiciona todos os objetos da lista dentro do array
            // temporario, tornando assim o array temporario exatamente igual a lista, mas
            // com um espaço a mais

            lista = temp; // o array principal recebe os valores do array temporario 
        } 
            id++; // incremento de 1 ao id;
            Produtos p = new Produtos(nome, categoria, qtd, undMed, valor); // instancia o produto
            lista[acc] = p; // o produto criado será colocado na posiçao do acumulador
            lista[acc].setId(id);
            acc++; // atribuiçao de 1 ao acumulador
             JOptionPane.showMessageDialog(null, "Produto cadastrado!");
    } else {
            JOptionPane.showMessageDialog(null, "Esse produto já existe no estoque, favor apenas atualizar");
        }
    }

    public static void findProduct(int id) { // procura as informações do produto no id digitado
        JOptionPane.showMessageDialog(null, lista[id - 1]); // mostra todas as informações do produto desejado
    }

    public static void findIndex(int id) { 
        if (id <= lista.length) { // if para verificar se o ID digitado está dentro da dimensão do array
            JOptionPane.showMessageDialog(null, "Índice no array: " + (id - 1));
        } else {
            JOptionPane.showMessageDialog(null, "Produto não cadastrado");
        }
    } // mostra o indice no array do produto desejado

    public static void removeProduct(int id, TelaPrincipal a1) { // aqui usamos um array temporario com o tamanho da lista - 1 para armazenar todos
        // os produtos menos o que o usuario escolher

        if (id <= lista.length) {
            Produtos temp[] = new Produtos[(lista.length - 1)]; // criando array temporario
            for (int i = 0; i < temp.length; i++) { // colocando todos os objetos do array principal dentro do array
                temp[i] = lista[i]; // temporario
            }
            for (int i = (id - 1); i < temp.length; i++) { // for para percorrer todo o array principal a
                // partir
                // do numero que o usuario informar - 1, e então
                // todos os produtos que estão no array
                // temporario
                // serão substuidos pelos que estão no índice do
                // array principal + 1, dessa forma, o produto
                // que
                // estava no ID que o usuário informou será
                // sobrescrito pelos subsequentes
                temp[i] = lista[i + 1];
                int idTemporario = (temp[i].getId() - 1); // substuindo o ID atual pelo novo (ID atual - 1)
                temp[i].setId(idTemporario); // setando o novo ID
            }
            lista = temp; // array principal recebendo todos os novos valores do array temporario
            
            JOptionPane.showMessageDialog(null, "Produto " + id + " excluído");
            acc--; // decremento do acc e do id para que os novos produtos criados sejam criados
            // com o id correto
            Controlador.id--; // decremento do id para que um novo cadastro de produto seja inserido com o ID correto
        } else {
            JOptionPane.showMessageDialog(null, "Produto não cadastrado");
        }
    }
    
    public static void updateProduct(int id, String nome, String categoria, double estoque, double undMed, double valor) { 
        // seta tudo que receber nos parametros como novo dado
        lista[id].setNome(nome);
        lista[id].setCategoria(categoria);
        lista[id].setEstoque(estoque);
        lista[id].setUndMed(undMed);
        lista[id].setVlrUnd(valor);
        JOptionPane.showMessageDialog(null, "Produto " + (id + 1) + " atualizado!", "Aviso!", 1);

    }
}
