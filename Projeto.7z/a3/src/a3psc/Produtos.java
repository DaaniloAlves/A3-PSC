package a3psc;

public final class Produtos {
    //ATRIBUTOS

    private int id;
    private String nomeDoProduto, categoria;
    private double estoque, undMed, vlrUnd;
    //METODOS

    public Produtos(String n, String c, double e, double undMed, double vlrUnd) {
        this.setNome(n);
        this.setCategoria(c);
        this.setEstoque(e);
        this.setUndMed(undMed);
        this.setVlrUnd(vlrUnd);
    }

    public Produtos() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nomeDoProduto;
    }

    public void setNome(String nomeDoProduto) {
        this.nomeDoProduto = nomeDoProduto;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getEstoque() {
        return estoque;
    }

    public void setEstoque(double estoque) {
        this.estoque = estoque;
    }

    public double getUndMed() {
        return undMed;
    }

    public void setUndMed(double undMed) {
        this.undMed = undMed;
    }

    public double getVlrUnd() {
        return vlrUnd;
    }

    public void setVlrUnd(double vlrUnd) {
        this.vlrUnd = vlrUnd;
    }

    @Override

    public String toString() {
        return "ID: " + this.getId() + "\n"
                + "Nome: " + this.getNome() + "\n"
                + "Categoria: " + this.getCategoria() + "\n"
                + "Quantidade em estoque: " + this.getEstoque() + "\n"
                + "Unidade de medida: " + this.getUndMed() + "\n"
                + "Preço: " + this.getVlrUnd() + "\n";
    }
}
